package com.urlshortener.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class UrlShortenerUtilTest {

    private final UrlShortenerUtil util = new UrlShortenerUtil();

    @Test
    @DisplayName("generateShortCode produces correct length")
    void generateShortCode_correctLength() {
        assertThat(util.generateShortCode(7)).hasSize(7);
        assertThat(util.generateShortCode(10)).hasSize(10);
    }

    @Test
    @DisplayName("generateShortCode uses only Base62 characters")
    void generateShortCode_base62Only() {
        String code = util.generateShortCode(50);
        assertThat(code).matches("[a-zA-Z0-9]+");
    }

    @RepeatedTest(5)
    @DisplayName("generateShortCode produces different codes across calls")
    void generateShortCode_isRandom() {
        String a = util.generateShortCode(7);
        String b = util.generateShortCode(7);
        // With 62^7 possibilities, collision probability is ~2.8e-10; safe to assert
        assertThat(a).isNotEqualTo(b);
    }

    @Test
    @DisplayName("hashUrl is deterministic")
    void hashUrl_deterministic() {
        String url = "https://example.com/very/long/path?q=test";
        assertThat(util.hashUrl(url)).isEqualTo(util.hashUrl(url));
    }

    @Test
    @DisplayName("hashUrl produces 64-character hex string (SHA-256)")
    void hashUrl_length() {
        assertThat(util.hashUrl("https://example.com")).hasSize(64);
    }

    @Test
    @DisplayName("hashUrl produces different hashes for different URLs")
    void hashUrl_unique() {
        assertThat(util.hashUrl("https://a.com"))
                .isNotEqualTo(util.hashUrl("https://b.com"));
    }

    @Test
    @DisplayName("isBot detects known bot user agents")
    void isBot_detection() {
        assertThat(util.isBot("Googlebot/2.1")).isTrue();
        assertThat(util.isBot("Mozilla/5.0 (compatible; bingbot/2.0)")).isTrue();
        assertThat(util.isBot("Mozilla/5.0 (Windows NT 10.0; Win64; x64)")).isFalse();
        assertThat(util.isBot(null)).isFalse();
    }

    @Test
    @DisplayName("detectDevice classifies correctly")
    void detectDevice_classification() {
        assertThat(util.detectDevice("Mozilla/5.0 (iPhone; CPU iPhone OS 14)")).isEqualTo("MOBILE");
        assertThat(util.detectDevice("Mozilla/5.0 (iPad; CPU OS 14)")).isEqualTo("TABLET");
        assertThat(util.detectDevice("Mozilla/5.0 (Windows NT 10.0; Win64)")).isEqualTo("DESKTOP");
        assertThat(util.detectDevice("Googlebot/2.1")).isEqualTo("BOT");
        assertThat(util.detectDevice(null)).isEqualTo("UNKNOWN");
    }
}
