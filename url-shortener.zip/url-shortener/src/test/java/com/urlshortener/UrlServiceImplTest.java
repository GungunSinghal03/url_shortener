package com.urlshortener.service;

import com.urlshortener.dto.request.CreateUrlRequest;
import com.urlshortener.dto.response.UrlResponse;
import com.urlshortener.exception.AliasAlreadyExistsException;
import com.urlshortener.exception.UrlExpiredException;
import com.urlshortener.exception.UrlNotFoundException;
import com.urlshortener.model.Url;
import com.urlshortener.repository.UrlAnalyticsRepository;
import com.urlshortener.repository.UrlRepository;
import com.urlshortener.service.impl.UrlServiceImpl;
import com.urlshortener.util.UrlShortenerUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UrlServiceImplTest {

    @Mock UrlRepository          urlRepository;
    @Mock UrlAnalyticsRepository analyticsRepository;
    @Mock UrlShortenerUtil        util;

    @InjectMocks UrlServiceImpl urlService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(urlService, "baseUrl",        "http://localhost:8080/api");
        ReflectionTestUtils.setField(urlService, "shortUrlLength", 7);
        ReflectionTestUtils.setField(urlService, "defaultExpiryDays", 30);
    }

    // ---- createShortUrl ------------------------------------------------

    @Test
    @DisplayName("Creates a new short URL and returns a response with a full short URL")
    void createShortUrl_newUrl_returnsResponse() {
        when(util.hashUrl(anyString())).thenReturn("abc123hash");
        when(urlRepository.findByUrlHashAndIsActiveTrue("abc123hash")).thenReturn(Optional.empty());
        when(util.generateShortCode(7)).thenReturn("aB3xK9z");
        when(urlRepository.existsByShortCode("aB3xK9z")).thenReturn(false);

        Url saved = Url.builder()
                .id(1L).shortCode("aB3xK9z")
                .originalUrl("https://example.com")
                .urlHash("abc123hash")
                .clickCount(0L).isActive(true)
                .createdAt(LocalDateTime.now())
                .build();
        when(urlRepository.save(any(Url.class))).thenReturn(saved);

        CreateUrlRequest req = CreateUrlRequest.builder()
                .originalUrl("https://example.com").build();

        UrlResponse result = urlService.createShortUrl(req, null);

        assertThat(result.getShortCode()).isEqualTo("aB3xK9z");
        assertThat(result.getShortUrl()).isEqualTo("http://localhost:8080/api/aB3xK9z");
        assertThat(result.getOriginalUrl()).isEqualTo("https://example.com");
    }

    @Test
    @DisplayName("Returns existing short URL when duplicate URL is submitted")
    void createShortUrl_duplicateUrl_returnsExisting() {
        Url existing = Url.builder()
                .id(2L).shortCode("exist1z")
                .originalUrl("https://example.com")
                .urlHash("abc123hash")
                .clickCount(5L).isActive(true)
                .createdAt(LocalDateTime.now())
                .build();

        when(util.hashUrl(anyString())).thenReturn("abc123hash");
        when(urlRepository.findByUrlHashAndIsActiveTrue("abc123hash"))
                .thenReturn(Optional.of(existing));

        UrlResponse result = urlService.createShortUrl(
                CreateUrlRequest.builder().originalUrl("https://example.com").build(), null);

        assertThat(result.getShortCode()).isEqualTo("exist1z");
        verify(urlRepository, never()).save(any());
    }

    @Test
    @DisplayName("Throws AliasAlreadyExistsException when alias is taken")
    void createShortUrl_aliasTaken_throwsConflict() {
        when(util.hashUrl(anyString())).thenReturn("hash999");
        when(urlRepository.findByUrlHashAndIsActiveTrue("hash999")).thenReturn(Optional.empty());
        when(urlRepository.existsByCustomAlias("my-alias")).thenReturn(true);

        CreateUrlRequest req = CreateUrlRequest.builder()
                .originalUrl("https://new.com")
                .customAlias("my-alias")
                .build();

        assertThatThrownBy(() -> urlService.createShortUrl(req, null))
                .isInstanceOf(AliasAlreadyExistsException.class);
    }

    // ---- resolveAndTrack -----------------------------------------------

    @Test
    @DisplayName("Resolves an active, non-expired short code and returns the original URL")
    void resolveAndTrack_validCode_returnsOriginalUrl() {
        Url url = Url.builder()
                .id(1L).shortCode("aB3xK9z")
                .originalUrl("https://example.com")
                .expiresAt(LocalDateTime.now().plusDays(10))
                .isActive(true).clickCount(0L)
                .build();

        when(urlRepository.findByShortCodeAndIsActiveTrue("aB3xK9z"))
                .thenReturn(Optional.of(url));

        String result = urlService.resolveAndTrack("aB3xK9z",
                new org.springframework.mock.web.MockHttpServletRequest());

        assertThat(result).isEqualTo("https://example.com");
        verify(urlRepository).incrementClickCount(1L);
    }

    @Test
    @DisplayName("Throws UrlNotFoundException for an unknown short code")
    void resolveAndTrack_unknownCode_throwsNotFound() {
        when(urlRepository.findByShortCodeAndIsActiveTrue("bad1234"))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> urlService.resolveAndTrack("bad1234",
                new org.springframework.mock.web.MockHttpServletRequest()))
                .isInstanceOf(UrlNotFoundException.class);
    }

    @Test
    @DisplayName("Throws UrlExpiredException for an expired short code")
    void resolveAndTrack_expiredCode_throwsGone() {
        Url url = Url.builder()
                .id(3L).shortCode("exp1234")
                .originalUrl("https://old.com")
                .expiresAt(LocalDateTime.now().minusDays(1))
                .isActive(true).clickCount(0L)
                .build();

        when(urlRepository.findByShortCodeAndIsActiveTrue("exp1234"))
                .thenReturn(Optional.of(url));

        assertThatThrownBy(() -> urlService.resolveAndTrack("exp1234",
                new org.springframework.mock.web.MockHttpServletRequest()))
                .isInstanceOf(UrlExpiredException.class);
    }
}
