package com.urlshortener.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class CreateUrlRequest {

    @NotBlank(message = "Original URL is required")
    @Pattern(
        regexp = "^(https?|ftp)://[^\\s/$.?#].[^\\s]*$",
        message = "Invalid URL format. Must start with http:// or https://"
    )
    @Size(max = 2048, message = "URL must not exceed 2048 characters")
    private String originalUrl;

    @Pattern(
        regexp = "^[a-zA-Z0-9_-]{3,50}$",
        message = "Alias must be 3-50 alphanumeric characters (hyphens/underscores allowed)"
    )
    private String customAlias;

    private LocalDateTime expiresAt;
}
