package com.urlshortener.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDateTime;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class UrlResponse {
    private Long id;
    private String shortCode;
    private String shortUrl;       // full short URL e.g. https://short.ly/aB3xK9z
    private String originalUrl;
    private String customAlias;
    private Long clickCount;
    private Boolean isActive;
    private LocalDateTime expiresAt;
    private LocalDateTime createdAt;
}
