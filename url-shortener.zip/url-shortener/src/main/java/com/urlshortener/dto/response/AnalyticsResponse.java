package com.urlshortener.dto.response;

import lombok.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AnalyticsResponse {

    private Long urlId;
    private String shortCode;
    private String originalUrl;
    private Long totalClicks;

    private List<DailyClick> dailyClicks;
    private Map<String, Long> clicksByCountry;
    private Map<String, Long> clicksByDevice;

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class DailyClick {
        private LocalDate date;
        private Long count;
    }
}
