package com.urlshortener.service.impl;

import com.urlshortener.model.Url;
import com.urlshortener.repository.UrlRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Periodically soft-deletes URLs whose expiry time has passed
 * and evicts them from the Redis cache.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ExpiryCleanupService {

    private final UrlRepository urlRepository;

    /**
     * Runs every 15 minutes. In a multi-instance deployment only one
     * pod should run this — use ShedLock or a dedicated cron pod.
     */
    @Scheduled(fixedRateString = "PT15M")
    @Transactional
    @CacheEvict(value = "urls", allEntries = true)
    public void cleanupExpiredUrls() {
        List<Url> expired = urlRepository.findByExpiresAtBeforeAndIsActiveTrue(LocalDateTime.now());
        if (expired.isEmpty()) return;

        expired.forEach(u -> u.setIsActive(false));
        urlRepository.saveAll(expired);
        log.info("Deactivated {} expired URL(s)", expired.size());
    }
}
