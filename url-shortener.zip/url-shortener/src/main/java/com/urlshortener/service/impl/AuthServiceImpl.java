package com.urlshortener.service.impl;

import com.urlshortener.dto.request.AuthRequest;
import com.urlshortener.dto.response.AuthResponse;
import com.urlshortener.exception.UserAlreadyExistsException;
import com.urlshortener.model.User;
import com.urlshortener.repository.UserRepository;
import com.urlshortener.security.JwtTokenProvider;
import com.urlshortener.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthServiceImpl implements AuthService {

    private final UserRepository        userRepository;
    private final PasswordEncoder       passwordEncoder;
    private final JwtTokenProvider      jwtTokenProvider;
    private final AuthenticationManager authenticationManager;

    @Override
    @Transactional
    public AuthResponse register(AuthRequest.Register req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new UserAlreadyExistsException("email", req.getEmail());
        }
        if (userRepository.existsByUsername(req.getUsername())) {
            throw new UserAlreadyExistsException("username", req.getUsername());
        }

        User user = User.builder()
                .email(req.getEmail())
                .username(req.getUsername())
                .passwordHash(passwordEncoder.encode(req.getPassword()))
                .isActive(true)
                .build();

        userRepository.save(user);
        log.info("Registered new user: {}", req.getEmail());

        String token = jwtTokenProvider.generateToken(user.getEmail());
        return buildAuthResponse(token, user);
    }

    @Override
    public AuthResponse login(AuthRequest.Login req) {
        // Delegates to Spring Security — throws BadCredentialsException on failure
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));

        User user = userRepository.findByEmail(req.getEmail()).orElseThrow();
        String token = jwtTokenProvider.generateToken(user.getEmail());
        log.info("User logged in: {}", req.getEmail());
        return buildAuthResponse(token, user);
    }

    private AuthResponse buildAuthResponse(String token, User user) {
        return AuthResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .expiresIn(86400L)   // 24 h in seconds
                .username(user.getUsername())
                .email(user.getEmail())
                .build();
    }
}
