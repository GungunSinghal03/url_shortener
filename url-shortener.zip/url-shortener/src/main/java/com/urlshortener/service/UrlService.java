package com.urlshortener.service;

import com.urlshortener.dto.request.CreateUrlRequest;
import com.urlshortener.dto.response.AnalyticsResponse;
import com.urlshortener.dto.response.UrlResponse;
import com.urlshortener.model.User;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UrlService {

    /** Create a new short URL. User may be null (anonymous). */
    UrlResponse createShortUrl(CreateUrlRequest request, User user);

    /**
     * Resolve a short code to its original URL.
     * Increments click count and records analytics asynchronously.
     */
    String resolveAndTrack(String shortCode, HttpServletRequest request);

    /** Soft-delete a URL (only the owner or admin may do this). */
    void deactivateUrl(String shortCode, User requestingUser);

    /** Paginated list of URLs belonging to a user. */
    Page<UrlResponse> getUserUrls(Long userId, Pageable pageable);

    /** Fetch per-link analytics summary. */
    AnalyticsResponse getAnalytics(String shortCode, User requestingUser);
}
