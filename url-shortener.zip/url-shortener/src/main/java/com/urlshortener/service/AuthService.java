package com.urlshortener.service;

import com.urlshortener.dto.request.AuthRequest;
import com.urlshortener.dto.response.AuthResponse;

public interface AuthService {
    AuthResponse register(AuthRequest.Register request);
    AuthResponse login(AuthRequest.Login request);
}
