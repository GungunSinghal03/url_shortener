package com.urlshortener.service.impl;

import com.urlshortener.dto.request.CreateUrlRequest;
import com.urlshortener.dto.response.AnalyticsResponse;
import com.urlshortener.dto.response.UrlResponse;
import com.urlshortener.exception.AliasAlreadyExistsException;
import com.urlshortener.exception.UrlExpiredException;
import com.urlshortener.exception.UrlNotFoundException;
import com.urlshortener.model.Url;
import com.urlshortener.model.UrlAnalytics;
import com.urlshortener.model.User;
import com.urlshortener.repository.UrlAnalyticsRepository;
import com.urlshortener.repository.UrlRepository;
import com.urlshortener.service.UrlService;
import com.urlshortener.util.UrlShortenerUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class UrlServiceImpl implements UrlService {

    private final UrlRepository          urlRepository;
    private final UrlAnalyticsRepository analyticsRepository;
    private final UrlShortenerUtil       util;

    @Value("${app.base-url}")
    private String baseUrl;

    @Value("${app.short-url-length:7}")
    private int shortUrlLength;

    @Value("${app.default-expiry-days:30}")
    private int defaultExpiryDays;

    // ----------------------------------------------------------------
    //  CREATE
    // ----------------------------------------------------------------

    @Override
    @Transactional
    public UrlResponse createShortUrl(CreateUrlRequest req, User user) {
        String originalUrl = req.getOriginalUrl().trim();
        String urlHash     = util.hashUrl(originalUrl);

        // 1. Duplicate check — same URL already in DB for this (or anonymous) context
        Optional<Url> existing = urlRepository.findByUrlHashAndIsActiveTrue(urlHash);
        if (existing.isPresent()) {
            Url existingUrl = existing.get();
            log.info("Duplicate URL detected, returning existing short code: {}", existingUrl.getShortCode());
            return buildResponse(existingUrl);
        }

        // 2. Custom alias validation
        String alias = req.getCustomAlias();
        if (alias != null && !alias.isBlank()) {
            if (urlRepository.existsByCustomAlias(alias)) {
                throw new AliasAlreadyExistsException(alias);
            }
        }

        // 3. Generate unique short code (retry on collision — extremely rare)
        String shortCode = (alias != null && !alias.isBlank())
                ? alias
                : generateUniqueCode();

        // 4. Resolve expiry
        LocalDateTime expiresAt = req.getExpiresAt() != null
                ? req.getExpiresAt()
                : LocalDateTime.now().plusDays(defaultExpiryDays);

        // 5. Persist
        Url url = Url.builder()
                .shortCode(shortCode)
                .originalUrl(originalUrl)
                .urlHash(urlHash)
                .customAlias(alias)
                .user(user)
                .expiresAt(expiresAt)
                .isActive(true)
                .clickCount(0L)
                .build();

        url = urlRepository.save(url);
        log.info("Created short URL: {} → {}", shortCode, originalUrl);
        return buildResponse(url);
    }

    // ----------------------------------------------------------------
    //  RESOLVE + TRACK
    // ----------------------------------------------------------------

    @Override
    @Transactional
    @Cacheable(value = "urls", key = "#shortCode")
    public String resolveAndTrack(String shortCode, HttpServletRequest request) {
        Url url = urlRepository.findByShortCodeAndIsActiveTrue(shortCode)
                .orElseThrow(() -> new UrlNotFoundException(shortCode));

        if (url.isExpired()) {
            // Soft-deactivate so future requests skip the DB
            url.setIsActive(false);
            urlRepository.save(url);
            throw new UrlExpiredException(shortCode);
        }

        // Atomic increment — avoids full entity load in hot path
        urlRepository.incrementClickCount(url.getId());

        // Fire-and-forget analytics write (does NOT block the redirect)
        recordAnalyticsAsync(url, request);

        return url.getOriginalUrl();
    }

    // ----------------------------------------------------------------
    //  DEACTIVATE
    // ----------------------------------------------------------------

    @Override
    @Transactional
    @CacheEvict(value = "urls", key = "#shortCode")
    public void deactivateUrl(String shortCode, User requestingUser) {
        Url url = urlRepository.findByShortCodeAndIsActiveTrue(shortCode)
                .orElseThrow(() -> new UrlNotFoundException(shortCode));

        // Only owner can deactivate
        if (url.getUser() == null || !url.getUser().getId().equals(requestingUser.getId())) {
            throw new AccessDeniedException("You do not own this URL.");
        }

        url.setIsActive(false);
        urlRepository.save(url);
        log.info("Deactivated URL: {}", shortCode);
    }

    // ----------------------------------------------------------------
    //  USER URLS
    // ----------------------------------------------------------------

    @Override
    @Transactional(readOnly = true)
    public Page<UrlResponse> getUserUrls(Long userId, Pageable pageable) {
        return urlRepository.findByUserIdAndIsActiveTrue(userId, pageable)
                .map(this::buildResponse);
    }

    // ----------------------------------------------------------------
    //  ANALYTICS
    // ----------------------------------------------------------------

    @Override
    @Transactional(readOnly = true)
    public AnalyticsResponse getAnalytics(String shortCode, User requestingUser) {
        Url url = urlRepository.findByShortCodeAndIsActiveTrue(shortCode)
                .orElseThrow(() -> new UrlNotFoundException(shortCode));

        if (url.getUser() != null && !url.getUser().getId().equals(requestingUser.getId())) {
            throw new AccessDeniedException("You do not own this URL.");
        }

        // Daily click data for last 30 days
        LocalDateTime from = LocalDateTime.now().minusDays(30);
        LocalDateTime to   = LocalDateTime.now();
        List<Object[]> rawDaily = analyticsRepository.findDailyClicksByUrlId(url.getId(), from, to);
        List<AnalyticsResponse.DailyClick> dailyClicks = rawDaily.stream()
                .map(row -> AnalyticsResponse.DailyClick.builder()
                        .date((LocalDate) row[0])
                        .count((Long) row[1])
                        .build())
                .toList();

        // Top 10 countries
        List<Object[]> rawCountries = analyticsRepository
                .findTopCountriesByUrlId(url.getId(), Pageable.ofSize(10));
        Map<String, Long> byCountry = new LinkedHashMap<>();
        rawCountries.forEach(r -> byCountry.put((String) r[0], (Long) r[1]));

        return AnalyticsResponse.builder()
                .urlId(url.getId())
                .shortCode(url.getShortCode())
                .originalUrl(url.getOriginalUrl())
                .totalClicks(url.getClickCount())
                .dailyClicks(dailyClicks)
                .clicksByCountry(byCountry)
                .build();
    }

    // ----------------------------------------------------------------
    //  PRIVATE HELPERS
    // ----------------------------------------------------------------

    /** Retry loop to handle the astronomically unlikely collision. */
    private String generateUniqueCode() {
        String code;
        int attempts = 0;
        do {
            code = util.generateShortCode(shortUrlLength);
            if (++attempts > 10) {
                // Extend length to escape a saturated key space
                shortUrlLength++;
                log.warn("Short code collision - increasing length to {}", shortUrlLength);
            }
        } while (urlRepository.existsByShortCode(code));
        return code;
    }

    /** Extract client IP, respecting reverse-proxy headers. */
    private String extractIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    @Async
    @Transactional
    public void recordAnalyticsAsync(Url url, HttpServletRequest request) {
        try {
            String ua         = request.getHeader("User-Agent");
            String referer    = request.getHeader("Referer");
            String ip         = extractIp(request);
            String deviceType = util.detectDevice(ua);

            UrlAnalytics analytics = UrlAnalytics.builder()
                    .url(url)
                    .ipAddress(ip)
                    .userAgent(ua)
                    .referer(referer)
                    .deviceType(UrlAnalytics.DeviceType.valueOf(deviceType))
                    .build();

            analyticsRepository.save(analytics);
        } catch (Exception e) {
            // Analytics must never break the redirect path
            log.error("Failed to record analytics for URL id={}", url.getId(), e);
        }
    }

    private UrlResponse buildResponse(Url url) {
        String shortUrl = baseUrl + "/" + url.getShortCode();
        return UrlResponse.builder()
                .id(url.getId())
                .shortCode(url.getShortCode())
                .shortUrl(shortUrl)
                .originalUrl(url.getOriginalUrl())
                .customAlias(url.getCustomAlias())
                .clickCount(url.getClickCount())
                .isActive(url.getIsActive())
                .expiresAt(url.getExpiresAt())
                .createdAt(url.getCreatedAt())
                .build();
    }
}
