package com.urlshortener.controller;

import com.urlshortener.service.UrlService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;

/**
 * Handles short-URL redirects.
 * Mapped to /s/{code} to keep the path short and separate from the API.
 *
 * HTTP 301 (Moved Permanently) → browsers cache the redirect; less server load.
 * HTTP 302 (Found)             → no caching; every click hits the server (needed for analytics).
 *
 * We use 302 so every click is counted.
 */
@RestController
@RequestMapping("/s")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Redirect", description = "Short URL redirect endpoint")
public class RedirectController {

    private final UrlService urlService;

    @GetMapping("/{shortCode}")
    @Operation(summary = "Redirect to the original URL")
    public ResponseEntity<Void> redirect(
            @PathVariable String shortCode,
            HttpServletRequest request) {

        String originalUrl = urlService.resolveAndTrack(shortCode, request);
        log.debug("Redirecting {} → {}", shortCode, originalUrl);

        return ResponseEntity.status(HttpStatus.FOUND)
                .header(HttpHeaders.LOCATION, originalUrl)
                .build();
    }
}
