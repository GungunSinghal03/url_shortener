package com.urlshortener.controller;

import com.urlshortener.dto.request.CreateUrlRequest;
import com.urlshortener.dto.response.AnalyticsResponse;
import com.urlshortener.dto.response.ApiResponse;
import com.urlshortener.dto.response.UrlResponse;
import com.urlshortener.model.User;
import com.urlshortener.repository.UserRepository;
import com.urlshortener.service.UrlService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/urls")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "URLs", description = "Create and manage short URLs")
public class UrlController {

    private final UrlService     urlService;
    private final UserRepository userRepository;

    // ----------------------------------------------------------------
    //  POST /urls — create short URL
    // ----------------------------------------------------------------

    @PostMapping
    @Operation(summary = "Create a short URL",
               security = @SecurityRequirement(name = "Bearer Authentication"))
    public ResponseEntity<ApiResponse<UrlResponse>> createUrl(
            @Valid @RequestBody CreateUrlRequest request,
            @AuthenticationPrincipal UserDetails principal) {

        User user = resolveUser(principal);
        UrlResponse response = urlService.createShortUrl(request, user);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Short URL created successfully", response));
    }

    // ----------------------------------------------------------------
    //  GET /urls/my — paginated list of the caller's URLs
    // ----------------------------------------------------------------

    @GetMapping("/my")
    @Operation(summary = "List my URLs",
               security = @SecurityRequirement(name = "Bearer Authentication"))
    public ResponseEntity<ApiResponse<Page<UrlResponse>>> getMyUrls(
            @AuthenticationPrincipal UserDetails principal,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "20") int size) {

        User user = resolveUser(principal);
        Page<UrlResponse> urls = urlService.getUserUrls(
                user.getId(),
                PageRequest.of(page, size, Sort.by("createdAt").descending()));
        return ResponseEntity.ok(ApiResponse.success(urls));
    }

    // ----------------------------------------------------------------
    //  DELETE /urls/{shortCode} — soft-delete
    // ----------------------------------------------------------------

    @DeleteMapping("/{shortCode}")
    @Operation(summary = "Deactivate a short URL",
               security = @SecurityRequirement(name = "Bearer Authentication"))
    public ResponseEntity<ApiResponse<Void>> deactivateUrl(
            @PathVariable String shortCode,
            @AuthenticationPrincipal UserDetails principal) {

        User user = resolveUser(principal);
        urlService.deactivateUrl(shortCode, user);
        return ResponseEntity.ok(ApiResponse.success("URL deactivated", null));
    }

    // ----------------------------------------------------------------
    //  GET /urls/{shortCode}/analytics
    // ----------------------------------------------------------------

    @GetMapping("/{shortCode}/analytics")
    @Operation(summary = "Get click analytics for a URL",
               security = @SecurityRequirement(name = "Bearer Authentication"))
    public ResponseEntity<ApiResponse<AnalyticsResponse>> getAnalytics(
            @PathVariable String shortCode,
            @AuthenticationPrincipal UserDetails principal) {

        User user = resolveUser(principal);
        AnalyticsResponse analytics = urlService.getAnalytics(shortCode, user);
        return ResponseEntity.ok(ApiResponse.success(analytics));
    }

    // ----------------------------------------------------------------
    //  Helper
    // ----------------------------------------------------------------

    private User resolveUser(UserDetails principal) {
        if (principal == null) return null;
        return userRepository.findByEmail(principal.getUsername()).orElse(null);
    }
}
