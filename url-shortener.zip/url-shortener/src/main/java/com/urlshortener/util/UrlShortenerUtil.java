package com.urlshortener.util;

import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HexFormat;

/**
 * Utility for short-code generation and URL hashing.
 *
 * <p>Short codes use Base62 (a-z A-Z 0-9). With 7 characters that gives
 * 62^7 ≈ 3.5 billion unique codes — plenty for a first production run.
 * At 1 M new links/day it takes ~9,500 years to exhaust.</p>
 */
@Component
public class UrlShortenerUtil {

    private static final String BASE62_CHARS =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int BASE = 62;
    private final SecureRandom random = new SecureRandom();

    /**
     * Generate a cryptographically random Base62 code.
     *
     * @param length desired code length (typically 7)
     */
    public String generateShortCode(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(BASE62_CHARS.charAt(random.nextInt(BASE)));
        }
        return sb.toString();
    }

    /**
     * SHA-256 hash of a URL — used for duplicate detection.
     * Storing the hash instead of the full URL keeps the index compact.
     */
    public String hashUrl(String url) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(url.getBytes());
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is always present in the JDK
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    /**
     * Detect common bot/crawler user agents.
     */
    public boolean isBot(String userAgent) {
        if (userAgent == null) return false;
        String ua = userAgent.toLowerCase();
        return ua.contains("bot") || ua.contains("crawler") || ua.contains("spider")
                || ua.contains("googlebot") || ua.contains("bingbot")
                || ua.contains("slurp") || ua.contains("duckduckbot");
    }

    /**
     * Coarse device classification from user agent string.
     */
    public String detectDevice(String userAgent) {
        if (userAgent == null) return "UNKNOWN";
        if (isBot(userAgent))  return "BOT";
        String ua = userAgent.toLowerCase();
        if (ua.contains("mobile") || ua.contains("android") || ua.contains("iphone"))
            return "MOBILE";
        if (ua.contains("tablet") || ua.contains("ipad"))
            return "TABLET";
        return "DESKTOP";
    }
}
