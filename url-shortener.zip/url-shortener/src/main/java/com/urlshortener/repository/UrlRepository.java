package com.urlshortener.repository;

import com.urlshortener.model.Url;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface UrlRepository extends JpaRepository<Url, Long> {

    // Primary lookup — used on every redirect (must be O(1))
    Optional<Url> findByShortCodeAndIsActiveTrue(String shortCode);

    Optional<Url> findByCustomAliasAndIsActiveTrue(String customAlias);

    // Duplicate detection — check by hash before inserting
    Optional<Url> findByUrlHashAndIsActiveTrue(String urlHash);

    // User's URLs with pagination
    Page<Url> findByUserIdAndIsActiveTrue(Long userId, Pageable pageable);

    // Expiry cleanup (scheduled job)
    List<Url> findByExpiresAtBeforeAndIsActiveTrue(LocalDateTime cutoff);

    boolean existsByShortCode(String shortCode);

    boolean existsByCustomAlias(String customAlias);

    // Atomic click-count increment (avoids full entity load + dirty check)
    @Modifying
    @Query("UPDATE Url u SET u.clickCount = u.clickCount + 1 WHERE u.id = :id")
    void incrementClickCount(@Param("id") Long id);
}
