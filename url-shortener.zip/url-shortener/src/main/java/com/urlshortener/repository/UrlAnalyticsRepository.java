package com.urlshortener.repository;

import com.urlshortener.model.UrlAnalytics;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface UrlAnalyticsRepository extends JpaRepository<UrlAnalytics, Long> {

    Page<UrlAnalytics> findByUrlId(Long urlId, Pageable pageable);

    long countByUrlId(Long urlId);

    // Clicks grouped by date (for time-series charts)
    @Query("""
        SELECT DATE(a.clickedAt) AS clickDate, COUNT(a) AS clickCount
        FROM UrlAnalytics a
        WHERE a.url.id = :urlId AND a.clickedAt BETWEEN :from AND :to
        GROUP BY DATE(a.clickedAt)
        ORDER BY clickDate ASC
        """)
    List<Object[]> findDailyClicksByUrlId(@Param("urlId") Long urlId,
                                          @Param("from")  LocalDateTime from,
                                          @Param("to")    LocalDateTime to);

    // Top countries
    @Query("""
        SELECT a.countryCode, COUNT(a) AS cnt
        FROM UrlAnalytics a
        WHERE a.url.id = :urlId AND a.countryCode IS NOT NULL
        GROUP BY a.countryCode
        ORDER BY cnt DESC
        """)
    List<Object[]> findTopCountriesByUrlId(@Param("urlId") Long urlId, Pageable pageable);
}
