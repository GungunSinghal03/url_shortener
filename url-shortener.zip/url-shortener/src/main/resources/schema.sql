-- ============================================================
--  URL Shortener Service — Database Schema
--  Optimized for high read traffic with proper indexing
-- ============================================================

CREATE DATABASE IF NOT EXISTS url_shortener CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE url_shortener;

-- ============================================================
-- users table — stores registered users (JWT auth)
-- ============================================================
CREATE TABLE users (
    id            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    email         VARCHAR(255)     NOT NULL,
    username      VARCHAR(100)     NOT NULL,
    password_hash VARCHAR(255)     NOT NULL,
    is_active     BOOLEAN          NOT NULL DEFAULT TRUE,
    created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email    (email),
    UNIQUE KEY uq_users_username (username),
    INDEX idx_users_email        (email)     -- fast login lookup
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- urls table — core table; one row per shortened link
-- ============================================================
CREATE TABLE urls (
    id             BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    short_code     VARCHAR(20)      NOT NULL,           -- e.g. "aB3xK9z"
    original_url   TEXT             NOT NULL,
    url_hash       VARCHAR(64)      NOT NULL,           -- SHA-256 of original_url → duplicate detection
    custom_alias   VARCHAR(100)     NULL,               -- user-supplied alias
    user_id        BIGINT UNSIGNED  NULL,               -- NULL → anonymous
    click_count    BIGINT UNSIGNED  NOT NULL DEFAULT 0,
    is_active      BOOLEAN          NOT NULL DEFAULT TRUE,
    expires_at     DATETIME         NULL,               -- NULL → never expires
    created_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_urls_short_code   (short_code),       -- O(1) redirect lookup
    UNIQUE KEY uq_urls_custom_alias (custom_alias),
    INDEX idx_urls_url_hash         (url_hash),         -- duplicate URL check
    INDEX idx_urls_user_id          (user_id),          -- "my links" queries
    INDEX idx_urls_expires_at       (expires_at),       -- expiry cleanup job
    INDEX idx_urls_created_at       (created_at),       -- date-range analytics

    CONSTRAINT fk_urls_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- url_analytics table — one row per click event
-- ============================================================
CREATE TABLE url_analytics (
    id            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    url_id        BIGINT UNSIGNED  NOT NULL,
    ip_address    VARCHAR(45)      NULL,                -- IPv4 or IPv6
    user_agent    VARCHAR(512)     NULL,
    referer       VARCHAR(2048)    NULL,
    country_code  VARCHAR(2)       NULL,                -- ISO 3166-1 alpha-2
    device_type   ENUM('DESKTOP','MOBILE','TABLET','BOT','UNKNOWN')
                                   NOT NULL DEFAULT 'UNKNOWN',
    clicked_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    INDEX idx_analytics_url_id      (url_id),           -- per-link stats
    INDEX idx_analytics_clicked_at  (clicked_at),       -- time-range analytics
    INDEX idx_analytics_country     (country_code),

    CONSTRAINT fk_analytics_url FOREIGN KEY (url_id)
        REFERENCES urls (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Partition url_analytics by month for scale
-- (enable once data grows beyond ~50M rows)
-- ============================================================
-- ALTER TABLE url_analytics
--   PARTITION BY RANGE (TO_DAYS(clicked_at)) (
--     PARTITION p_2024_01 VALUES LESS THAN (TO_DAYS('2024-02-01')),
--     PARTITION p_2024_02 VALUES LESS THAN (TO_DAYS('2024-03-01')),
--     ...
--     PARTITION p_future  VALUES LESS THAN MAXVALUE
--   );
