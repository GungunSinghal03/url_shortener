# 🔗 URL Shortener Service

A **production-ready URL Shortener** built with Java 17, Spring Boot 3, MySQL 8, and Redis.
Comparable to Bitly in architecture — featuring JWT auth, analytics, rate limiting, caching, and clean layered architecture.

---

## 📁 Folder Structure

```
url-shortener/
├── src/
│   ├── main/
│   │   ├── java/com/urlshortener/
│   │   │   ├── UrlShortenerApplication.java      ← Entry point
│   │   │   ├── config/
│   │   │   │   ├── AsyncConfig.java               ← @Async thread pool
│   │   │   │   ├── OpenApiConfig.java             ← Swagger/OpenAPI
│   │   │   │   ├── RedisConfig.java               ← Redis cache setup
│   │   │   │   └── SecurityConfig.java            ← JWT + route security
│   │   │   ├── controller/
│   │   │   │   ├── AuthController.java            ← /auth/register, /auth/login
│   │   │   │   ├── RedirectController.java        ← /s/{code}  (hot path)
│   │   │   │   └── UrlController.java             ← /urls CRUD + analytics
│   │   │   ├── dto/
│   │   │   │   ├── request/
│   │   │   │   │   ├── AuthRequest.java
│   │   │   │   │   └── CreateUrlRequest.java
│   │   │   │   └── response/
│   │   │   │       ├── AnalyticsResponse.java
│   │   │   │       ├── ApiResponse.java           ← Unified response wrapper
│   │   │   │       ├── AuthResponse.java
│   │   │   │       └── UrlResponse.java
│   │   │   ├── exception/
│   │   │   │   ├── AliasAlreadyExistsException.java
│   │   │   │   ├── GlobalExceptionHandler.java    ← @RestControllerAdvice
│   │   │   │   ├── RateLimitExceededException.java
│   │   │   │   ├── UrlExpiredException.java
│   │   │   │   ├── UrlNotFoundException.java
│   │   │   │   └── UserAlreadyExistsException.java
│   │   │   ├── filter/
│   │   │   │   ├── JwtAuthenticationFilter.java   ← Bearer token extractor
│   │   │   │   └── RateLimitingFilter.java        ← Bucket4j per-IP limiter
│   │   │   ├── model/
│   │   │   │   ├── Url.java
│   │   │   │   ├── UrlAnalytics.java
│   │   │   │   └── User.java
│   │   │   ├── repository/
│   │   │   │   ├── UrlAnalyticsRepository.java
│   │   │   │   ├── UrlRepository.java
│   │   │   │   └── UserRepository.java
│   │   │   ├── security/
│   │   │   │   ├── CustomUserDetailsService.java
│   │   │   │   └── JwtTokenProvider.java
│   │   │   ├── service/
│   │   │   │   ├── AuthService.java
│   │   │   │   ├── UrlService.java
│   │   │   │   └── impl/
│   │   │   │       ├── AuthServiceImpl.java
│   │   │   │       ├── ExpiryCleanupService.java  ← @Scheduled cleanup
│   │   │   │       └── UrlServiceImpl.java
│   │   │   └── util/
│   │   │       └── UrlShortenerUtil.java          ← Base62 + SHA-256
│   │   └── resources/
│   │       ├── application.yml
│   │       └── schema.sql
│   └── test/java/com/urlshortener/
│       ├── UrlServiceImplTest.java
│       └── UrlShortenerUtilTest.java
├── .env.example
├── .gitignore
├── docker-compose.yml
├── Dockerfile
└── pom.xml
```

---

## 🚀 Quick Start

### Prerequisites
- Java 17+, Maven 3.8+
- Docker & Docker Compose

### Run with Docker (recommended)

```bash
# 1. Clone and enter the project
git clone <repo-url> && cd url-shortener

# 2. Set up environment
cp .env.example .env    # edit values as needed

# 3. Start everything (MySQL + Redis + App)
docker compose up --build

# 4. Open Swagger UI
open http://localhost:8080/api/swagger-ui.html
```

### Run locally (dev mode)

```bash
# Start MySQL and Redis only
docker compose up mysql redis -d

# Run the Spring Boot app
./mvnw spring-boot:run
```

---

## 🌐 API Endpoints

### Auth

| Method | Path             | Auth | Description        |
|--------|------------------|------|--------------------|
| POST   | /auth/register   | ❌   | Register new user  |
| POST   | /auth/login      | ❌   | Login, get JWT     |

### URL Management

| Method | Path                         | Auth | Description              |
|--------|------------------------------|------|--------------------------|
| POST   | /urls                        | ✅   | Create short URL         |
| GET    | /urls/my                     | ✅   | List my URLs (paginated) |
| DELETE | /urls/{shortCode}            | ✅   | Deactivate a URL         |
| GET    | /urls/{shortCode}/analytics  | ✅   | Click analytics          |

### Redirect

| Method | Path            | Auth | Description                       |
|--------|-----------------|------|-----------------------------------|
| GET    | /s/{shortCode}  | ❌   | Redirect to original URL (302)    |

---

## 📬 Request / Response Examples

### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "alice@example.com",
  "username": "alice",
  "password": "securePass123"
}
```
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiJ9...",
    "tokenType": "Bearer",
    "expiresIn": 86400,
    "username": "alice",
    "email": "alice@example.com"
  }
}
```

### Create Short URL
```http
POST /api/urls
Authorization: Bearer <token>
Content-Type: application/json

{
  "originalUrl": "https://www.example.com/very/long/path?with=params",
  "customAlias": "my-link",
  "expiresAt": "2026-12-31T23:59:59"
}
```
```json
{
  "success": true,
  "message": "Short URL created successfully",
  "data": {
    "id": 42,
    "shortCode": "my-link",
    "shortUrl": "http://localhost:8080/api/s/my-link",
    "originalUrl": "https://www.example.com/very/long/path?with=params",
    "customAlias": "my-link",
    "clickCount": 0,
    "isActive": true,
    "expiresAt": "2026-12-31T23:59:59",
    "createdAt": "2026-04-03T10:00:00"
  }
}
```

### Redirect
```http
GET /api/s/my-link
```
```
HTTP/1.1 302 Found
Location: https://www.example.com/very/long/path?with=params
```

### Analytics
```http
GET /api/urls/my-link/analytics
Authorization: Bearer <token>
```
```json
{
  "success": true,
  "data": {
    "urlId": 42,
    "shortCode": "my-link",
    "originalUrl": "https://www.example.com/...",
    "totalClicks": 1284,
    "dailyClicks": [
      { "date": "2026-04-01", "count": 430 },
      { "date": "2026-04-02", "count": 512 },
      { "date": "2026-04-03", "count": 342 }
    ],
    "clicksByCountry": {
      "IN": 600, "US": 400, "DE": 284
    }
  }
}
```

### Error Response (example)
```json
{
  "success": false,
  "error": "Short URL not found: bad123",
  "timestamp": 1712134567890
}
```

---

## 🗄️ Database Schema

```sql
users          → id, email, username, password_hash, is_active
urls           → id, short_code (UNIQUE), original_url, url_hash (INDEX),
                 custom_alias (UNIQUE), user_id (FK), click_count,
                 is_active, expires_at (INDEX)
url_analytics  → id, url_id (FK+INDEX), ip_address, user_agent,
                 referer, country_code, device_type, clicked_at (INDEX)
```

See `src/main/resources/schema.sql` for the full DDL with all indexes.

---

## 🏗️ Design Decisions

### Short Code Generation (Base62)
- 7 Base62 characters → **3.5 billion unique codes**
- `SecureRandom` prevents enumeration attacks
- At 1 M new links/day the space lasts ~9,500 years
- On the astronomically unlikely collision, the service retries and auto-extends length

### Duplicate URL Detection
- SHA-256 hash of the original URL is stored in an indexed `url_hash` column
- Before creating a new row we check the hash — **O(1) indexed lookup**
- Saves storage and returns the existing short code instantly

### Read-Path Optimisation (the hot path)
```
Browser → RedirectController → Redis cache (hit: ~1 ms)
                             ↘ MySQL lookup (miss: ~5 ms)
                             → HTTP 302 redirect
                             → async analytics write (non-blocking)
```
- `@Cacheable("urls")` — resolved URLs stay in Redis for 30 min
- `urlRepository.incrementClickCount()` — single-column atomic UPDATE, no dirty-check overhead
- Analytics written on a separate `@Async` thread pool — **never blocks the redirect**

### Rate Limiting (Bucket4j)
- Token-bucket algorithm: 20 requests/minute per IP by default
- Returns `Retry-After` header so clients know when to retry
- **Production upgrade**: replace the in-memory `ConcurrentHashMap` with `bucket4j-redis`
  so limits are shared across all application instances

### JWT Authentication
- Stateless HS256 JWT, 24-hour expiry
- Stored in `Authorization: Bearer <token>` header — no cookies, no CSRF risk
- URLs can be created anonymously (user = null) — no forced sign-up

### Soft Deletes
- `is_active = false` instead of physical DELETE
- Keeps analytics history intact
- A scheduled job (`ExpiryCleanupService`) deactivates expired links every 15 minutes

---

## 📈 Scaling to Millions of Users

### Phase 1 — Vertical + Cache (0 → 500 K req/day)
- Single server + MySQL + Redis (as configured here)
- Redis absorbs ~95% of redirect traffic at <1 ms latency

### Phase 2 — Horizontal Scaling (500 K → 50 M req/day)

```
                    ┌─────────────────────────────┐
Internet ──► CDN ──► Load Balancer (AWS ALB / Nginx)
                    └────┬────────┬────────┬──────┘
                         │        │        │
                    ┌────▼─┐  ┌───▼──┐  ┌─▼────┐
                    │ App  │  │ App  │  │ App  │  ← Stateless pods
                    │  1   │  │  2   │  │  3   │    (Kubernetes)
                    └────┬─┘  └──────┘  └──────┘
                         │
              ┌──────────┼────────────┐
              ▼          ▼            ▼
         Redis Cluster  MySQL     Analytics DB
         (read cache)  Primary +  (ClickHouse /
                       Replicas   TimescaleDB)
```

- **Stateless app** — any instance can serve any request (JWT, no session)
- **MySQL read replicas** — route `SELECT` to replicas, `INSERT/UPDATE` to primary
- **Redis Cluster** — distribute cache across shards; use `bucket4j-redis` for shared rate limits
- **Analytics offload** — write click events to a message queue (Kafka) and process asynchronously into ClickHouse for fast aggregations

### Phase 3 — Global Scale (50 M+ req/day)
- **Multi-region deployment** (AWS Route53 latency routing)
- **URL database sharding** by `short_code` hash (Vitess or AWS Aurora Sharded)
- **Snowflake IDs** instead of auto-increment to avoid cross-shard collisions
- **Partition `url_analytics`** by month (see commented SQL in `schema.sql`)
- **CDN-level redirect caching** (CloudFront Lambda@Edge) — 0 ms for popular links

---

## ⚖️ Trade-offs

| Decision | Benefit | Cost |
|---|---|---|
| 302 redirect (not 301) | Every click is counted | Browser doesn't cache; extra RTT for repeat visitors |
| Soft delete | History preserved | Table grows; needs periodic archival |
| In-memory rate limit buckets | Zero infra | Not shared across instances |
| Async analytics | Redirect <2 ms | Very small chance of missing a click on crash |
| SHA-256 for duplicate detection | O(1) exact match | Extra 64-byte column per row |
| Base62 random codes | Simple, fast | No guaranteed monotonic order |

---

## ☁️ Deployment Guide

### AWS (Production)

```
ECR (Docker image)
  → ECS Fargate (app, auto-scaling)
  → RDS MySQL Multi-AZ
  → ElastiCache Redis Cluster
  → ALB + ACM (HTTPS)
  → Route 53 (custom domain)
  → CloudWatch (logs + alerts)
```

Recommended instance sizes to start:
- App: 2 × `t3.medium` (Fargate tasks, min 2 for HA)
- MySQL: `db.t3.medium` Multi-AZ
- Redis: `cache.t3.micro` cluster mode

### Render (Quick / Budget)

1. Push image to Docker Hub
2. Create **Web Service** from Docker image
3. Add **MySQL** and **Redis** add-ons
4. Set environment variables from `.env.example`
5. Enable auto-deploy on `main` branch

### Environment Variables (required in prod)

```
DB_USERNAME, DB_PASSWORD
REDIS_HOST, REDIS_PORT, REDIS_PASSWORD
BASE_URL          # public URL of your service
JWT_SECRET        # min 32 random chars (openssl rand -base64 64)
```

---

## 🔒 Security Checklist

- [x] Passwords hashed with BCrypt (cost factor 12)
- [x] JWT signed with HMAC-SHA256
- [x] Input validated with Bean Validation + regex
- [x] Rate limiting on all endpoints (20 req/min/IP)
- [x] Non-root Docker user
- [x] Stack traces never returned to client
- [x] HTTPS enforced in production (ALB / Render TLS)
- [ ] IP-based geo-blocking (add via WAF)
- [ ] OWASP dependency check in CI (`mvn dependency-check:check`)

---

## 🧪 Running Tests

```bash
./mvnw test
```

Test coverage includes:
- `UrlServiceImplTest` — unit tests for all service methods (Mockito)
- `UrlShortenerUtilTest` — Base62 generation, SHA-256 hashing, device detection

---

## 📊 Monitoring

- **Health check**: `GET /api/actuator/health`
- **Metrics (Prometheus)**: `GET /api/actuator/prometheus`
- **Swagger UI**: `GET /api/swagger-ui.html`

Suggested dashboards: Grafana + Prometheus for redirect latency p99, cache hit rate, error rate.
